<?php
session_start();
include 'db.php';

// Pastikan pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Set the time zone to your local time zone
date_default_timezone_set('Asia/Jakarta'); // Change to your time zone if needed

// Ambil username dari session
$username = $_SESSION['username'];

// Fungsi untuk mendapatkan keranjang dari session
function getCart() {
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    return $_SESSION['cart'];
}

// Ambil keranjang belanja
$cart = getCart();
$total_price = 0;

// Hitung total harga
if (is_array($cart)) {
    foreach ($cart as $item) {
        if (is_array($item) && isset($item['sellprice']) && isset($item['quantity'])) {
            $total_price += $item['sellprice'] * $item['quantity'];
        }
    }
}

// Proses pembayaran
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Tentukan direktori upload dan pastikan direktori ada
    $upload_dir = 'uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true); // Membuat folder uploads jika belum ada
    }

    // Cek apakah direktori dapat ditulis
    if (!is_writable($upload_dir)) {
        $_SESSION['error_message'] = "The upload directory is not writable.";
    } else {
        // Upload bukti pembayaran
        if (isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] == UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
            $file_tmp = $_FILES['payment_proof']['tmp_name'];
            $file_name = basename($_FILES['payment_proof']['name']);
            $file_size = $_FILES['payment_proof']['size'];
            $file_type = mime_content_type($file_tmp);

            if (!in_array($file_type, $allowed_types)) {
                $_SESSION['error_message'] = "Invalid file type. Only JPG, JPEG, and PNG are allowed.";
            } elseif ($file_size > 2 * 1024 * 1024) {
                $_SESSION['error_message'] = "File size exceeds the limit of 2MB.";
            } else {
                // Menambahkan timestamp pada nama file untuk mencegah bentrok nama
                $file_path = $upload_dir . time() . "_" . $file_name;

                // Proses pembayaran setelah file berhasil di-upload
                $order_date = date('Y-m-d H:i:s');  // Get the current local date and time using the correct time zone

                // Ambil customer_id dari database berdasarkan username
                $sql = "SELECT c.cid FROM customers c
                JOIN users u ON u.name = c.fullname
                WHERE u.name = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $username);
                $stmt->execute();

                // Check for SQL errors
                if ($stmt->error) {
                echo "SQL error: " . $stmt->error;
                exit;
                }

                $stmt->store_result();

                // Check if user exists
                if ($stmt->num_rows == 0) {
                $_SESSION['error_message'] = "Customer not found.";
                header("Location: login.php");
                exit;
                }

                // Bind the result to the customer_id variable
                $stmt->bind_result($customer_id);
                $stmt->fetch(); // Fetch the result

                // Loop melalui setiap item dalam keranjang belanja
                foreach ($cart as $item) {
                    if (is_array($item)) {
                        $total_amount = $item['sellprice'] * $item['quantity'];
                        
                        // SQL untuk memasukkan data ke tabel orders
                        $sql = "INSERT INTO orders (cid, pid, quantity, order_date, total_amount, payment_proof) 
                                VALUES (?, ?, ?, ?, ?, ?)";
                        $stmt = $conn->prepare($sql);
                        
                        // Bind parameter
                        $stmt->bind_param("iiisds", 
                            $customer_id,
                            $item['product_id'], 
                            $item['quantity'],
                            $order_date,  // Use the current date and time here
                            $total_amount,
                            $file_path
                        );
                        
                        // Eksekusi query
                        $stmt->execute();
                    }
                }

                // Kosongkan keranjang setelah berhasil
                unset($_SESSION['cart']);
                $_SESSION['success_message'] = "Payment successful and order placed!";
                header("Location: order.php");  // Redirect to Order Product page
                exit;
            }
        } else {
            $_SESSION['error_message'] = "Please upload a valid payment proof.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../css/style.css">
    <title>Payment - Semkama</title>
</head>
<body class="bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 min-h-screen flex">

    <!-- Sidebar -->
    <div class="w-64 bg-white shadow-lg flex flex-col min-h-screen">
        <div class="bg-gray-300 rounded-t-lg py-6 px-4 text-center">
            <h2 class="text-4xl font-bold text-gray-600 mb-4">Menu</h2>
        </div>
        <div class="bg-gray-200 rounded-b-lg flex flex-col py-6 px-4 h-full">
            <a href="dashboard.php" class="block bg-indigo-500 text-white text-center px-6 py-2 rounded-lg shadow-md hover:bg-indigo-600 transition mb-4">Dashboard</a>
            <a href="order.php" class="block bg-indigo-500 text-white text-center px-6 py-2 rounded-lg shadow-md hover:bg-indigo-600 transition mb-4">Order Product</a>
            <a href="logout.php" class="block bg-indigo-500 text-white text-center px-6 py-2 rounded-lg shadow-md hover:bg-indigo-600 transition">Logout</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="flex-1 px-6 py-10">
        <div class="bg-white rounded-lg shadow-lg p-8 mb-10 text-center">
            <h1 class="text-4xl font-bold text-gray-800 mb-4">Payment</h1>
        </div>

        <!-- Menampilkan pesan sukses atau error -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="bg-green-500 text-white p-4 mb-4 rounded">
                <?php echo $_SESSION['success_message']; ?>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php elseif (isset($_SESSION['error_message'])): ?>
            <div class="bg-red-500 text-white p-4 mb-4 rounded">
                <?php echo $_SESSION['error_message']; ?>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <!-- Tabel Barang yang Dibeli -->
        <div class="bg-white rounded-lg shadow-lg p-8 mb-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Items in Your Cart</h2>
            <table class="table-auto w-full text-left border-collapse">
                <thead>
                    <tr>
                        <th class="border-b p-2">Product</th>
                        <th class="border-b p-2">Quantity</th>
                        <th class="border-b p-2">Price</th>
                        <th class="border-b p-2">Total</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (is_array($cart)): ?>
                    <?php foreach ($cart as $item): ?>
                        <?php if (isset($item['sellprice']) && isset($item['quantity'])): ?>
                        <tr>
                            <td class="border-b p-2"><?php echo htmlspecialchars($item['name'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td class="border-b p-2"><?php echo (int) $item['quantity']; ?></td>
                            <td class="border-b p-2">Rp <?php echo number_format((float) $item['sellprice'], 0, ',', '.'); ?></td>
                            <td class="border-b p-2">Rp <?php echo number_format((float) $item['sellprice'] * (int) $item['quantity'], 0, ',', '.'); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
            <div class="mt-4 text-right text-xl font-bold">Total: Rp <?php echo number_format($total_price, 0, ',', '.'); ?></div>
        </div>

        <!-- Form Upload Bukti Pembayaran -->
        <div class="bg-white rounded-lg shadow-lg p-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Upload Payment Proof</h2>
            <form action="payment.php" method="POST" enctype="multipart/form-data">
                <div class="mb-4">
                    <label for="payment_proof" class="block text-gray-600">Payment Proof</label>
                    <input type="file" id="payment_proof" name="payment_proof" class="w-full mt-2 p-2 border rounded focus:outline-none focus:ring focus:ring-indigo-300" accept="image/jpeg, image/png" required>
                </div>

                <button type="submit" class="w-full bg-indigo-500 text-white py-2 rounded hover:bg-indigo-600">Submit Payment</button>
            </form>
        </div>
    </div>

    <!-- Popup Notification (JS) -->
    <script>
        <?php if (isset($_SESSION['success_message'])): ?>
            alert("<?php echo $_SESSION['success_message']; ?>");
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
    </script>
</body>
</html>
