<?php
session_start();
include 'db.php';

// Pastikan pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Ambil username dari session
$username = $_SESSION['username'];

// Fungsi untuk mendapatkan keranjang dari session
function getCart() {
    // Debugging: Log the state of the cart
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    } elseif (!is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    return $_SESSION['cart'];
}

// Fungsi untuk menambahkan item ke keranjang
function addToCart($product_id, $product_name, $price, $quantity) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    $found = false;
    for ($i = 0; $i < count($_SESSION['cart']); $i++) {
        if ($_SESSION['cart'][$i]['product_id'] == $product_id) {
            $_SESSION['cart'][$i]['quantity'] += $quantity;
            $found = true;
            break;
        }
    }

    if (!$found) {
        $_SESSION['cart'][] = [
            'product_id' => $product_id,
            'name' => $product_name,
            'sellprice' => $price,
            'quantity' => $quantity
        ];
    }

    // Debugging: Log the cart content to check if items are added
    var_dump($_SESSION['cart']);
}


// Proses penambahan ke keranjang
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Ambil data produk dari database
    $sql = "SELECT * FROM products WHERE pid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
        $product_name = $product['productname'];
        $price = $product['sellprice'];

        // Tambahkan ke keranjang
        addToCart($product_id, $product_name, $price, $quantity);
        $_SESSION['success_message'] = "Product added to cart successfully!";
    } else {
        $_SESSION['error_message'] = "Product not found.";
    }

    header("Location: order.php");
    exit;
}

$cart = getCart();

$total_price = 0;
if (is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        if (is_array($item) && isset($item['sellprice']) && isset($item['quantity'])) {
            $total_price += $item['sellprice'] * $item['quantity'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../css/style.css">
    <title>Order - Semkama</title>
</head>
<body class="bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 min-h-screen flex">

    <!-- Sidebar -->
    <div class="w-64 bg-white shadow-lg flex flex-col min-h-screen">
        <div class="bg-gray-300 rounded-t-lg py-6 px-4 text-center">
            <h2 class="text-4xl font-bold text-gray-600 mb-4">Menu</h2>
        </div>
        <div class="bg-gray-200 rounded-b-lg flex flex-col py-6 px-4 h-full">
            <a href="dashboard.php" class="block bg-indigo-500 text-white text-center px-6 py-2 rounded-lg shadow-md hover:bg-indigo-600 transition mb-4">Dashboard</a>
            <a href="order.php" class="block bg-indigo-500 text-white text-center px-6 py-2 rounded-lg shadow-md hover:bg-indigo-600 transition mb-4">Order Product</a>
            <a href="logout.php" class="block bg-indigo-500 text-white text-center px-6 py-2 rounded-lg shadow-md hover:bg-indigo-600 transition">Logout</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="flex-1 px-6 py-10">
        <div class="bg-white rounded-lg shadow-lg p-8 mb-10 text-center">
            <h1 class="text-4xl font-bold text-gray-800 mb-4">Order Product</h1>
        </div>

        <!-- Menampilkan pesan sukses atau error -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="bg-green-500 text-white p-4 mb-4 rounded">
                <?php echo $_SESSION['success_message']; ?>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php elseif (isset($_SESSION['error_message'])): ?>
            <div class="bg-red-500 text-white p-4 mb-4 rounded">
                <?php echo $_SESSION['error_message']; ?>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <!-- Form Pemesanan -->
        <div class="bg-white rounded-lg shadow-lg p-8 mb-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Place Your Order</h2>
            <form action="order.php" method="POST">
                <div class="mb-4">
                    <label for="product_id" class="block text-gray-600">Product</label>
                    <select name="product_id" id="product_id" class="w-full mt-2 p-2 border rounded focus:outline-none focus:ring focus:ring-indigo-300" required>
                        <option value="">Select a product</option>
                        <?php
                        $sql = "SELECT * FROM products";
                        $result = $conn->query($sql);
                        while ($product = $result->fetch_assoc()) {
                            echo "<option value='" . $product['pid'] . "'>" . $product['productname'] . " - Rp " . number_format($product['sellprice'], 0, ',', '.') . "</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-4">
                    <label for="quantity" class="block text-gray-600">Quantity</label>
                    <input type="number" id="quantity" name="quantity" min="1" class="w-full mt-2 p-2 border rounded focus:outline-none focus:ring focus:ring-indigo-300" required>
                </div>

                <button type="submit" class="w-full bg-indigo-500 text-white py-2 rounded hover:bg-indigo-600">Add to Cart</button>
            </form>
        </div>

        <!-- Tabel Keranjang -->
        <div class="bg-white rounded-lg shadow-lg p-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Your Cart</h2>
            <table class="table-auto w-full text-left border-collapse">
                <thead>
                    <tr>
                        <th class="border-b p-2">Product</th>
                        <th class="border-b p-2">Quantity</th>
                        <th class="border-b p-2">Price</th>
                        <th class="border-b p-2">Total</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (is_array($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                    <?php foreach ($_SESSION['cart'] as $item): ?>
                        <?php if (isset($item['sellprice']) && isset($item['quantity'])): ?>
                        <tr>
                            <td class="border-b p-2"><?php echo htmlspecialchars($item['name'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td class="border-b p-2"><?php echo (int) $item['quantity']; ?></td>
                            <td class="border-b p-2">Rp <?php echo number_format((float) $item['sellprice'], 0, ',', '.'); ?></td>
                            <td class="border-b p-2">Rp <?php echo number_format((float) $item['sellprice'] * (int) $item['quantity'], 0, ',', '.'); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="border-b p-2 text-center">Your cart is empty.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
            <div class="mt-4 text-right text-xl font-bold">Total: Rp <?php echo number_format($total_price, 0, ',', '.'); ?></div>

            <!-- Tombol Checkout -->
            <div class="mt-6 text-center">
                <a href="payment.php" class="inline-block w-full bg-indigo-500 text-white px-6 py-2 rounded hover:bg-indigo-600 transition">
                    Checkout
                </a>
            </div>
        </div>
    </div>
</body>
</html>
